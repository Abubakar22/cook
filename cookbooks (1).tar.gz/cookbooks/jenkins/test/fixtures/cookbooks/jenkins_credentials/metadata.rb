name 'jenkins_credentials'
depends 'jenkins_server_wrapper'
