name 'jenkins_plugin'
depends 'jenkins_server_wrapper'
