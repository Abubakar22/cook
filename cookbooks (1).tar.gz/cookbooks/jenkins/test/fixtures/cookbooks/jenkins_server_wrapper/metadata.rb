name 'jenkins_server_wrapper'
depends 'java'
depends 'jenkins'
