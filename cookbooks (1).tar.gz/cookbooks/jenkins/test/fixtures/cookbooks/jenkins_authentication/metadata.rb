name 'jenkins_authentication'
depends 'jenkins_server_wrapper'
