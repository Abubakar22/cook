require 'spec_helper'

describe service('jenkins') do
  it 'cannot have a reliably tested command' do
    pending('cannot have a reliably tested command')
    raise
  end
end
