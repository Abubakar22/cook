#
# Cookbook:: testing
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
#

print("********************* HELLO ***********************************")
print("###############################################################")
