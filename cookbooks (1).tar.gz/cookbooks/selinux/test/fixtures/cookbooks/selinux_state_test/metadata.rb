name 'selinux_state_test'
version '0.0.1'
depends 'selinux'
