use_inline_resources

action :run do
end
