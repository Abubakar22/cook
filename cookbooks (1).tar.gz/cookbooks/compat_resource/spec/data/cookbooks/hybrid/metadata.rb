name "hybrid"
description "cookbook that depends on compat_resource, but has LWRPs"
version "1.0.0"
depends "compat_resource"
