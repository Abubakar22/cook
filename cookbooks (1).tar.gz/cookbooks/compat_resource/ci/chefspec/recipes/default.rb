
file "/tmp/foo.xyz"
