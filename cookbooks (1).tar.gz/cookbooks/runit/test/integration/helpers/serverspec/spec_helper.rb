require 'serverspec'
set :backend, :exec

puts "os: #{os}"
