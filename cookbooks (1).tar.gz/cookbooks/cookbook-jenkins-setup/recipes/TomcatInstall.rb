include_recipe 'java'

#disable selinux
selinux_state 'SELinux Disabled' do
  action :disabled
end

tomcat_install 'jenkins' do
  tomcat_user 'jenkins'
  tomcat_group 'jenkins'
end

#Setting up home directory for jenkins webapp
directory '/home/jenkins' do
  owner 'jenkins'
  group 'jenkins'  
  action :create
end

remote_file '/opt/tomcat_jenkins/webapps/jenkins.war' do
  owner 'jenkins'
  mode '0644'
  source 'http://mirrors.jenkins.io/war-stable/2.60.1/jenkins.war'
  checksum '34fde424dde0e050738f5ad1e316d54f741c237bd380bd663a07f96147bb1390'
end

tomcat_service 'jenkins' do
  action [:start, :enable]
  env_vars [{'CATALINA_BASE' => '/opt/tomcat_jenkins'}, {'CATALINA_PID' => '/opt/tomcat_jenkins/tomcat_jenkins.pid'}]
  sensitive true
  tomcat_user 'jenkins'
  tomcat_group 'jenkins'
end

#Install plugins
node['jenkins']['plugins'].each do |plugin|
  jenkins_plugin plugin do
    install_deps true
  end
