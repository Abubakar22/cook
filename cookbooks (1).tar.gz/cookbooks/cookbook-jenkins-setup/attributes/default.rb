node.normal["java"]["jdk_version"] = "8"
default['jenkins']['master']['jvm_options'] = '-Djenkins.install.runSetupWizard=false'
default['jenkins']['plugins'] = [
  'crowd2',
  'artifactory',
  'docker-plugin',
  'sonar',
]
