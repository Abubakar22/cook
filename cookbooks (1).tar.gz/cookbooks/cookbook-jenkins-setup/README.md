# cookbook-jenkins-setup

TODO: Enter the cookbook description here.

