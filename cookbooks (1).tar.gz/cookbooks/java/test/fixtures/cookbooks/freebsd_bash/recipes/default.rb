# Need bash installed to use bats
package 'bash' if platform_family?('freebsd')
